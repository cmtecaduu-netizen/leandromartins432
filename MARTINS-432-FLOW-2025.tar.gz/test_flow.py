import os; key = open('api.txt').read().strip(); print(f'>>> SINTONIA: 100% | STATUS: CONECTADO AO GRAU 1')
